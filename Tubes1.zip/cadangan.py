def importCSV(filename,delimeter=';'):
    file=open(filename,'r')
    dataframe={}
    headers=splitstr(file.readline().replace('\n',''),delimeter)
    for line in file:
        linedata=splitstr(line.replace('\n',''),delimeter)
        row={}
        for x in range(len(headers)):
            if(x in range(len(linedata))):
                row[headers[x]]=linedata[x]
            else:
                row[headers[x]]="null"
        dataframe[linedata[0]]=[row]
    file.close()
    return dataframe