def splitstr(str,sep):
    # Fungsi split()
    str1=""
    list1=[]
    for i in str:
        if(i!=sep):
            str1=str1+i
        else:
            list1= list1+[str1]
            str1=""
    if(str !=""):
        list1= list1+[str1]
    return list1

def importCSV(filename,delimeter=';'):
    # Fungsi Untuk membaca File CSV
    file=open(filename,'r')
    dataframe={}
    headers=splitstr(file.readline().replace('\n',''),delimeter)
    for line in file:
        linedata=splitstr(line.replace('\n',''),delimeter)
        dataframe[linedata[0]]=linedata
    file.close()
    return dataframe

def writeDU(filename,username,password,role):
    # Fungsi untuk menulis di datauser
    file=open(filename,'a')
    file.write("\n"+username+";"+password+";"+role)
    file.close()

def login():
    # Fungsi untuk login
    username=input("Username : ")
    password=input("Password : ")
    cek=False
    # Cek apakah username terdaftar atau tidak
    for x in datauser:
        if(username==x):
            cek=True
    # Cek apakah password benar atau salah
    if(cek==True):
        if(datauser[username][1]==password):
            print("Selamat datang,",username+"!")
        else:
            print("Password salah!")
    else:
        print("Username tidak terdaftar!")

def summonjin():
    # Fungsi untuk summon jin
    print("Jenis jin yang dapat dipanggil:")
    print(" (1) Pengumpul - Bertugas mengumpulkan bahan bangunan")
    print(" (2) Pembangun - Bertugas membangun candi")
    print()
    nomorjenis=input("Masukkan nomor jenis jin yang ingin dipanggil: ")
    print()
    # Cek apakah nomorjenis valid atau tidak
    while not(nomorjenis=="1" or nomorjenis=="2"):
        print("Tidak ada jenis jin bernomor "+'"'+nomorjenis+'" !')
        print()
        nomorjenis=input("Masukkan nomor jenis jin yang ingin dipanggil: ")
        print()
    if(nomorjenis=="1"):
        print("Memilih jin “Pengumpul”.")
        print()
        cek=True
        while(cek==True):
            cek=False
            username=input("Masukkan username jin: ")
            for x in datauser:
                if(username==x):
                    cek=True
            if(cek==True):
                print()
                print("username "+'"'+username+'"'+" sudah diambil!")
                print()
        password=input("Masukkan password jin: ")
        while(len(password)<5 or len(password)>25):
            print()
            print("Password panjangnya harus 5-25 karakter!")
            print()
            password=input("Masukkan password jin: ")
        writeDU("user.csv",username,password,"jin_pengumpul")

    else:
        print("Memilih jin “Pembangun”.")
        print()
        cek=True
        while(cek==True):
            cek=False
            username=input("Masukkan username jin: ")
            for x in datauser:
                if(username==x):
                    cek=True
            if(cek==True):
                print()
                print("username "+'"'+username+'"'+" sudah diambil!")
                print()
        password=input("Masukkan password jin: ")
        while(len(password)<5 or len(password)>25):
            print()
            print("Password panjangnya harus 5-25 karakter!")
            print()
            password=input("Masukkan password jin: ")
        writeDU("user.csv",username,password,"jin_pembangun")

    print()
    print("Mengumpulkan sesajen...")
    print("Menyerahkan sesajen...")
    print("Membacakan mantra...")
    print()
    print("Jin "+username+" berhasil dipanggil!")

        
datauser=importCSV("user.csv")
#login()
#summonjin()

